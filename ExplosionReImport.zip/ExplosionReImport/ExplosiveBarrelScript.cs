using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosiveBarrelScript : MonoBehaviour
{
    bool exploding;
    float tolerance = 1.25f;

    void FixedUpdate()
    {
        if (GetComponent<Rigidbody>().velocity.magnitude > tolerance) {
            triggerExplosionWithDelay(Random.Range(.1f, .4f));
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if (!other.transform.CompareTag("Ground")) {
            triggerExplosionWithDelay(Random.Range(.1f, .4f));
        }
    }

    public void triggerExplosion()
    {
        GetComponent<ExplosionScript>().Explode();
        Destroy(gameObject);
    }

    public void triggerExplosionWithDelay(float delay)
    {
        if (!exploding) {
            exploding = true;
            Invoke("triggerExplosion", delay);
        }
    }
}
