using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosionScript : MonoBehaviour
{
    public float blastRadius;
    public float blastForce;

    public bool testButton;

    void Start()
    {
        //Explode();
    }

    private void Update()
    {
        if (testButton) { Explode(); testButton = false; }
    }

    public void Explode()
    {
        Collider[] objectsWithinRadius = Physics.OverlapSphere(transform.position, blastRadius);
        //Debug.Log(objectsWithinRadius.Length);

        foreach (Collider objectHit in objectsWithinRadius) {
            Vector3 dir = (objectHit.transform.position - transform.position).normalized;
            RaycastHit hit;

            if (Physics.Raycast(transform.position, dir, out hit, blastRadius)) {
                if (hit.transform.GetComponent<Rigidbody>() != null) {
                    Rigidbody rb = hit.transform.GetComponent<Rigidbody>();

                    float dis = Vector3.Distance(hit.transform.position, transform.position);
                    float appliedForce = blastForce * (1 - dis / blastRadius);
                    //Debug.Log(appliedForce);
                    rb.AddForce(dir * appliedForce, ForceMode.Impulse);

                    //if dealing damage:
                    //check if enemy/has the health-bearing script
                    //if so, write equation using 'appliedForce'
                }
                if (hit.transform.GetComponent<ExplosiveBarrelScript>() != null) {
                    hit.transform.GetComponent<ExplosiveBarrelScript>().triggerExplosionWithDelay(Random.Range(.1f, .4f));
                }
            }
        }
    }
}
